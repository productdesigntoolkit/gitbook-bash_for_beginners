# Assets

Dieser Ordner enthält Bilder und andere Medien für das Buch.

## Empfohlene Bilder

- `cover.png` – Buchcover (1600×2400px)
- `terminal-screenshot.png` – Screenshot eines Terminals
- `file-structure.png` – Dateisystem-Diagramm

## Bildformate

- PNG für Screenshots und Diagramme
- SVG für Vektorgrafiken
- JPG für Fotos
